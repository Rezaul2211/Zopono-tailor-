# Zopono Tailor

Premium custom tailoring & bespoke fashion e-commerce site — React + Vite (TypeScript) frontend, Firebase (Auth + Firestore) for data, and a Gemini-powered "AI Style Advisor" chat.

## Run locally

**Prerequisites:** Node.js 18+

1. Install dependencies:
   ```
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in your keys (Gemini + Firebase — see below).
3. Run the app:
   ```
   npm run dev
   ```
   Opens at http://localhost:3000

## Environment variables

| Variable | Used for |
|---|---|
| `GEMINI_API_KEY` | Powers the "AI Style Advisor" chat. Get one free at https://aistudio.google.com/apikey |
| `VITE_FIREBASE_*` | Firebase Auth + Firestore (your product catalog, orders, users, reviews). Get these from your Firebase project → Project settings → General → Your apps. |

See `.env.example` for the full list.

## Deploying

### Vercel (recommended)
1. Push this project to a GitHub/GitLab/Bitbucket repo.
2. Import it at https://vercel.com/new — Vercel auto-detects the Vite frontend and the `/api/tailor-advisor.ts` serverless function.
3. In the Vercel project's **Settings → Environment Variables**, add `GEMINI_API_KEY` and all the `VITE_FIREBASE_*` variables from `.env.example`.
4. Deploy. Done — no `vercel.json` edits needed, it's already configured.

### Any Node host (Render, Railway, Fly.io, a VPS, etc.)
This project also ships a small Express server (`server.ts`) that serves the built frontend and the `/api/tailor-advisor` endpoint from one process:
```
npm install
npm run build
npm start
```
Set the same environment variables from `.env.example` on your host before starting it. The server listens on port 3000 (or `process.env.PORT` if your host requires a specific port — set `PORT` and it will be picked up).

### Static-only hosts (Netlify, GitHub Pages, Cloudflare Pages)
These can serve the frontend (`npm run build:vercel`, then upload the `dist/` folder), but you'll need to host `/api/tailor-advisor` separately (e.g. as a Netlify/Cloudflare Function, reusing the logic in `api/tailor-advisor.ts`), or point the AI chat feature to wherever you deploy that function.

## Firestore security rules
`firestore.rules` in this repo defines who can read/write your `products`, `orders`, `users`, etc. collections. Deploy them with the Firebase CLI:
```
firebase deploy --only firestore:rules
```
