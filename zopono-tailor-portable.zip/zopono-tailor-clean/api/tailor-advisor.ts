import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';

// This function runs as a serverless endpoint at POST /api/tailor-advisor
// on Vercel. It is the same logic used by server.ts for other Node hosts
// (Render, Railway, a VPS, etc.) — see SYSTEM_INSTRUCTION below.

const SYSTEM_INSTRUCTION = `You are the Zopono Master Tailor & AI Style Advisor.
You are an expert in bespoke custom tailoring, suit fitting, fabric selection (e.g. Italian Super 120s Wool, Egyptian Giza Cotton, Mulberry Silk, Linen, Premium Blends), exact body measurement guidelines, and occasion styling (Weddings, Galas, Executive Meetings, Festive Eid, Casual Chic).
Provide warm, professional, concise, and actionable advice.
Suggest matching colors, lapel styles (Notch, Peak, Shawl), cuff types, and fitting preferences (Slim Fit, Tailored Fit, Classic Fit) when relevant. Keep answers helpful and conversational.`;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, history } = req.body ?? {};

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not set in environment.');
    }
    const ai = new GoogleGenAI({ apiKey });

    const formattedContents: { role: string; parts: { text: string }[] }[] = [];
    if (Array.isArray(history) && history.length > 0) {
      for (const h of history.slice(-6)) {
        formattedContents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.content }],
        });
      }
    }
    formattedContents.push({ role: 'user', parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: formattedContents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const reply = response.text || "I'm sorry, I couldn't generate a recommendation right now. Please ask again!";
    return res.status(200).json({ reply });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({
      error: 'Failed to consult AI Tailor Advisor',
      details: error?.message || String(error),
    });
  }
}
